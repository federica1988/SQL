USE `toysgroup`;

-- Tabelle Gerarchie
CREATE TABLE Category (
CategoryID INT PRIMARY KEY,
CategoryName VARCHAR(255) NOT NULL);

CREATE TABLE State (
StateID INT PRIMARY KEY,
StateName VARCHAR(255) NOT NULL);

-- Tabella Prodotto
CREATE TABLE Product (
ProductID INT PRIMARY KEY,
ProductName VARCHAR(250) NOT NULL,
CategoryID INT NOT NULL,
FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID));
    
-- Tabella Regioni
CREATE TABLE Region (
RegionID INT PRIMARY KEY,
RegionName VARCHAR(250) NOT NULL,
StateID INT NOT NULL,
FOREIGN KEY (StateID) REFERENCES State(StateID));

-- Tabella Sales
CREATE TABLE Sales (
TransactionID INT PRIMARY KEY,
ProductID INT NOT NULL,
RegionID INT NOT NULL,
SaleDate DATE NOT NULL,
Price DECIMAL(10, 2) NOT NULL,
FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
FOREIGN KEY (RegionID) REFERENCES Region(RegionID));
    
-- Inserimento dati nelle tabelle gerarchiche
INSERT INTO Category (CategoryID, CategoryName) VALUES 
(1, 'Toys'),
(2, 'Giochi_da_tavola'),
(3, 'Videogames');

INSERT INTO State (StateID, StateName) VALUES 
(1, 'France'),
(2, 'Germany'),
(3, 'Italy'),
(4, 'Greece');

-- Inserimento dati nella tabella Product
INSERT INTO Product (ProductID, ProductName, CategoryID) VALUES
(1, 'Action Figure', 1),
(2, 'Puzzle', 2),
(3, 'Gameboy', 3);

-- Inserimento dati nella tabella Region
INSERT INTO Region (RegionID, RegionName, StateID) VALUES
(1, 'WestEurope', 1),
(2, 'SouthEurope', 2);

-- Inserimento dati nella tabella Sales
INSERT INTO Sales (TransactionID, ProductID, RegionID, SaleDate, Price) VALUES 
(1, 1, 1, '2024-02-25', 50.00),
(2, 1, 2, '2023-02-28', 40.00),
(3, 2, 2, '2023-01-29', 60.00);

INSERT INTO Sales (TransactionID, ProductID, RegionID, SaleDate, Price) VALUES 
(7, 3, 1, '2023-03-15', 70.00),
(6, 3, 2, '2023-05-20', 90.00);

-- Verifica campi PK univoci
SELECT COUNT(DISTINCT ProductID) = COUNT(*) AS PK_Uniqueness FROM Product;
SELECT COUNT(DISTINCT RegionID) = COUNT(*) AS PK_Uniqueness FROM Region;
SELECT COUNT(DISTINCT TransactionID) = COUNT(*) AS PK_Uniqueness FROM Sales;
SELECT COUNT(DISTINCT CategoryID) = COUNT(*) AS PK_Uniqueness FROM Category;
SELECT COUNT(DISTINCT StateID) = COUNT(*) AS PK_Uniqueness FROM State;

--Fatturato per prodotto per anno
SELECT p.ProductName, YEAR(s.SaleDate) AS sales_year, SUM(s.Price) AS total_revenue
FROM Product p
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName, YEAR(s.SaleDate);

--Fatturato per stato per anno (ordinato per data e fatturato decrescente)
SELECT st.StateName, YEAR(s.SaleDate) AS Anno, SUM(s.Price) AS FatturatoTotale
FROM State st
JOIN Region r ON st.StateID = r.StateID
JOIN Sales s ON r.RegionID = s.RegionID
GROUP BY st.StateName, YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate), FatturatoTotale DESC;

--Categoria più richiesta
SELECT c.CategoryName, COUNT(p.ProductID) AS ProductNumber
FROM Category c
JOIN Product p ON c.CategoryID = p.CategoryID
GROUP BY c.CategoryName
ORDER BY ProductNumber DESC
LIMIT 1;

--Prodotti invenduti (1_Approccio)
SELECT ProductName
FROM Product
WHERE ProductID NOT IN (SELECT ProductID FROM Sales);

--Prodotti invenduti (2_Approccio)
SELECT p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.TransactionID IS NULL;

--Data di vendita più recente per prodotto
SELECT p.ProductName, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName;

--Bonus
SELECT s.TransactionID, s.SaleDate, p.ProductName, c.CategoryName, st.StateName, r.RegionName,
       CASE WHEN DATEDIFF(CURDATE(), s.SaleDate) > 180 THEN 1 ELSE 0 END AS Passato180Giorni
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Region r ON s.RegionID = r.RegionID
JOIN State st ON r.StateID = st.StateID;





 
 
 
 